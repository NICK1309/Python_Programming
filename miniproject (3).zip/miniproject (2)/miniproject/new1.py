from tkinter import *
from tkinter.ttk import Combobox
win=Tk()
win.config(bg='sky blue')
win.title("Login Window")


def clrfield():
    t1.delete(0, END)

def showrec():
    mydb = mysql.connector.connect(
        user="root",
        password="",
        host="localhost",
        database="pms")
    mycur = mydb.cursor()
    mycur.execute("select lead_Name from student ")
    mydata = mycur.fetchone()
    if mydata == None:
        t1.insert(0, '1')
    else:
        cnt = mydata[0] + 1
        t1.insert(0, cnt)


l1 = Label(win, text="Mentor name ", bg="white", fg="black")
l1.place(x=90, y=270)
data = ("Ashish awate", "vijayalaxmi bittal", "mayuri kulkarni", "khalid Alfatmi")
t1 = Combobox(win, values=data)
t1.place(x=280, y=270)
t1.bind('<<ComboboxSelected>>',showrec)
win.geometry("1500x1500")
win.mainloop()